package com.letap.letaptech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.letap")
public class LetaptechApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetaptechApplication.class, args);
		System.out.println("hii");
	}

}
