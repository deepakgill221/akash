package com.letap.letaptech;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.letap.dao.PaymentDao;
import com.letap.entity.Payment;

@RestController
public class LetapController {
	
	@Autowired PaymentDao dao;
	
	@GetMapping(value="/")
	public List<Payment> getEmployees()
    {
      List<Payment> paymentList = new ArrayList<>();
      // n is no. of objects
      int n=2;
      try {
      for(int iteration=1; iteration<=n; iteration++) {
    	  
    	  Date paymentdate = new Date();
    		Calendar calender = Calendar.getInstance(); 
    		calender.setTime(paymentdate); 
    		calender.add(Calendar.DATE, iteration);
    		paymentdate = calender.getTime();
    	  paymentList.add(new Payment(iteration,1234L+iteration,paymentdate));  
      }
      dao.savePaymentDetails(paymentList);
      }catch (Exception e) {
		e.printStackTrace();
	}
      return paymentList;
    }


}
