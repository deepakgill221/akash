package com.letap.dao;

import java.util.List;

import com.letap.entity.Payment;

public interface PaymentDao {

	void savePaymentDetails(List<Payment> payment);

}
