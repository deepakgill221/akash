package com.letap.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.letap.entity.Payment;


/*
 * @author Akash Piperseniya
 * @description  DAO implementation class for saving payment object 
 * @since 2nd July 2019
 * @version 1.0
 */
@Repository
@Transactional
public class PaymentDaoImpl implements PaymentDao {

	@Autowired LocalSessionFactoryBean localbean;

	/*
	 * 
	 * @see com.letap.dao.PaymentDao#savePaymentDetails(java.util.List)
	 */
	@Override
	public void savePaymentDetails(List<Payment> payments) {
		try {
			for (Payment payment : payments) {
				localbean.getObject().getCurrentSession().save(payment);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
