package com.letap.dao;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.letap.entity.Payment;

/*
 * @author Akash Piperseniya
 * @description  Service implementation for sorting based on payment business logic 
 * @since 2nd July 2019
 * @version 1.0
 */
@Service
public class SortingMethods  {

	/*
	 * @description sorting payments based on payment date
	 * @inputParam list of payment objects
	 * @return sorted list of payment objects
	 */
	public List<Payment> sortPaymentByDate(List<Payment> payments) {
		try {
			Collections.sort(payments, new Comparator<Payment>() {
				public int compare(Payment m1, Payment m2) {
					return m1.getPaymentDate().compareTo(m2.getPaymentDate());
				}
			});
		}catch (Exception e) {
			e.printStackTrace();
			payments = null;
		}
		return payments;
	}

	/*
	 * @description sorting payments based on payment date
	 * @inputParam list of payment objects
	 * @return sorted list of payment objects
	 */
	public List<Payment> sortPaymentByDate1(List<Payment> payments) {

		boolean sorted = false;
		try {
			while(!sorted) {
				sorted = true;
				for (int index = 0; index < payments.size() - 1; index++) {
					if ((payments.get(index).getPaymentDate()).before(payments.get(index+1).getPaymentDate())) {
						Collections.swap(payments, index, index+1); 
						sorted = false;
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			payments = null;
		}
		return payments;
	}
	
	/*
	 * @description sorting payments based on payment date
	 * @inputParam list of payment objects
	 * @return sorted list of payment objects
	 */
	public List<Payment> sortPaymentByDate2(List<Payment> payments) {
		try {
			for (int i = 0; i < payments.size(); i++) {

		          for (int j = payments.size() - 1; j > i; j--) {
		              if (payments.get(i).getPaymentDate().before(payments.get(j).getPaymentDate()) ) {

		            	  Payment tmp = payments.get(i);
		                  payments.set(i,payments.get(j)) ;
		                  payments.set(j,tmp);
		              }
		          }
		      }
		}catch (Exception e) {
			e.printStackTrace();
			payments = null;
		}
		return payments;
	}
}
