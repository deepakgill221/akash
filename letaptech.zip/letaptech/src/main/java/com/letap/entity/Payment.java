package com.letap.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*
 * @author Akash Piperseniya
 * @description  Payment entity class
 * @since 2nd July 2019
 * @version 1.0
 */
@Entity
@Table(name="PAYMENTS")
public class Payment {
	
	@Id
	@GeneratedValue(generator="my_gen")
	@SequenceGenerator(name="my_gen",sequenceName="PAYMENTS_Seq1",allocationSize=1)
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private int pamentNumber;
	private long paymentAmount;
	private Date paymentDate;
	public int getPamentNumber() {
		return pamentNumber;
	}
	public void setPamentNumber(int pamentNumber) {
		this.pamentNumber = pamentNumber;
	}
	public long getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(long paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	@Override
	public String toString() {
		return "Payment [pamentNumber=" + pamentNumber + ", paymentAmount=" + paymentAmount + ", paymentDate="
				+ paymentDate + "]";
	}
	
	public Payment() {
		super();
	}
	
	public Payment(int pamentNumber, long paymentAmount, Date paymentDate) {
		super();
		this.pamentNumber = pamentNumber;
		this.paymentAmount = paymentAmount;
		this.paymentDate = paymentDate;
	}
	
	

}
